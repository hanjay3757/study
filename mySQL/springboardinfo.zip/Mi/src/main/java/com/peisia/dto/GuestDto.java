package com.peisia.dto;

import lombok.Data;

//lombok에서 꺼내옴
@Data
public class GuestDto {
	private Long bno;
	private String btext;
}