function dw(str){
    document.write(str);
}
function br(){
    document.write("<br>");
}
function r(max){
    var x = Math.floor(Math.random()*max)+1;
    return x;}
