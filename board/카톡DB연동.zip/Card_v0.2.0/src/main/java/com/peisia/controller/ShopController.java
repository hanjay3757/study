package com.peisia.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.peisia.service.ShopService;

import lombok.Setter;

@CrossOrigin(origins = "http://localhost:3000") // 3000포트에서의 요청 허용
@RequestMapping("/shop/*")
@RestController
public class ShopController {

	@Setter(onMethod_ = @Autowired)
	private ShopService service;

	// 카카오페이 결제 준비 API 호출

	// 결제 성공 처리

	// 결제 실패 처리
	@GetMapping("/fail")
	public String kakaoPayFail() {
		// 카카오페이 결제 실패 처리
		return "결제 실패! 다시 시도해주세요.";
	}

	// 결제 취소 처리
	@GetMapping("/cancel")
	public String kakaoPayCancel() {
		// 카카오페이 결제 취소 처리
		return "결제가 취소되었습니다.";
	}
}
