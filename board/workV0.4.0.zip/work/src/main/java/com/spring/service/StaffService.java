package com.spring.service;

import java.util.ArrayList;

import com.spring.dto.StaffDto;

public interface StaffService {
	public ArrayList<StaffDto> getList();

	public StaffDto read(long bno);

	public void remove(Long bno);
}
