package com.spring.dto;

import lombok.Data;

@Data
public class StaffDto {
	private Long no;
	private String grade;
	private String id;
	private String field;
	private Long delete;

	public StaffDto() {
	};

	public StaffDto(Long no, String grade, String id, String field, Long delete) {
		super();
		this.no = no;
		this.grade = grade;
		this.id = id;
		this.field = field;
		this.delete = delete;
	}
}
