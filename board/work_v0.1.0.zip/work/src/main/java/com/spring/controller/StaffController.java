package com.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.service.StaffService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/staff/*")
@AllArgsConstructor
@Controller
public class StaffController {
	private StaffService service;

	@GetMapping("/list")
	public String getList(Model model) {
		log.info("직원 목록 요청");
		model.addAttribute("list", service.getList());
	}
}
