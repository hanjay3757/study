package com.spring.controller;

public class StuffController {

}
