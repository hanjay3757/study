package com.spring.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.spring.dto.StaffDto;
import com.spring.service.StaffService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/staff/*")
@AllArgsConstructor
@Controller
public class StaffController {
	private StaffService service;

//	@GetMapping("/getList") // 프로젝트 루트 경로 이하 /guest/getList url 진입 시 여기로 진입하게 됨.
//	public void getList(Model model) { // 매개변수에 Model m 식으로 작성하게 되면, 스프링이 알아서 모델 객체를 만들어서 넘겨줌.
//		model.addAttribute("list", service.getList());
//	} // 위 /getList 와 동일한 jsp파일을 염. 상위 경로 포함(/guest). 즉 PJ루트/guest/getList.jsp 파일 염.
//// 그리고 이 파일은 
//// PJ\src\main\webapp\WEB-INF\views\guest\getList.jsp
//// 에 만들어 놓으면 됨.
//
//}

	@GetMapping("/list") // 여기를 수정
	public String getList(Model model) { // void를 String으로 변경
		model.addAttribute("list", service.getList());
		return "staff/list"; // 명시적으로 뷰 이름 반환
	}

	@GetMapping("/read")
	public void read(@RequestParam("bno") Long bno, Model model) {
		log.info("글 번호 =======" + bno);
		model.addAttribute("read", service.read(bno));
	}

	@GetMapping("/remove")
	public String remove(@RequestParam("bno") Long bno, HttpSession session) {
		// 로그인 체크 및 관리자 권한 확인
		StaffDto loginStaff = (StaffDto) session.getAttribute("loginStaff");
		if (loginStaff == null || loginStaff.getAdmins() != 1) {
			return "redirect:/staff/login"; // 권한 없으면 로그인 페이지로
		}

		log.info("삭제:" + bno);
		service.remove(bno);
		return "redirect:/staff/list";
	}

	@PostMapping("/restore")
	public String restore(@RequestParam("bno") Long bno, HttpSession session) {
		StaffDto loginStaff = (StaffDto) session.getAttribute("loginStaff");

		// 관리자가 아니면 접근 불가
		if (loginStaff == null || loginStaff.getAdmins() != 1) {
			return "redirect:/staff/login";
		}

		service.restore(bno);
		return "redirect:/staff/removelist";
	}

	@GetMapping("/removelist")
	public String getRemoveList(Model model, HttpSession session) {
		// 로그인 체크
		StaffDto loginStaff = (StaffDto) session.getAttribute("loginStaff");

		// 로그인되지 않았거나 관리자가 아닌 경우
		if (loginStaff == null || loginStaff.getAdmins() != 1) {
			return "redirect:/staff/login";
		}

		model.addAttribute("loginStaff", loginStaff);
		model.addAttribute("list", service.getDeletedList());
		return "staff/removelist";
	}

	@GetMapping("/login")
	public String loginForm() {
		return "staff/login"; // login.jsp로 이동
	}

	@PostMapping("/login")
	public String login(@RequestParam("staffId") String staffId, @RequestParam("password") String password,
			HttpSession session, Model model) {
		StaffDto staff = service.login(staffId, password);

		if (staff != null) {
			session.setAttribute("loginStaff", staff);
			return "redirect:/stuff/item/list";
		} else {
			model.addAttribute("error", "아이디 또는 비밀번호가 올바르지 않습니다.");
			return "staff/login";
		}
	}

	@GetMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/staff/login";
	}

	// 수정 페이지로 이동
	@GetMapping("/edit")
	public String editForm(@RequestParam("bno") Long bno, Model model, HttpSession session) {
		StaffDto loginStaff = (StaffDto) session.getAttribute("loginStaff");
		if (loginStaff == null || loginStaff.getAdmins() != 1) {
			return "redirect:/staff/login";
		}
		
		StaffDto staff = service.read(bno);
		if (staff == null) {
			return "redirect:/staff/list";
		}
		
		model.addAttribute("staff", staff);
		return "staff/edit";
	}

	// 수정 처리
	@PostMapping("/edit")
	public String edit(StaffDto staffDto, HttpSession session) {
		StaffDto loginStaff = (StaffDto) session.getAttribute("loginStaff");
		if (loginStaff == null || loginStaff.getAdmins() != 1) {
			return "redirect:/staff/login";
		}
		
		service.update(staffDto);
		return "redirect:/staff/list";
	}
}
