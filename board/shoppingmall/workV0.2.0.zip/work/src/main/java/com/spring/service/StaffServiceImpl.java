package com.spring.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.dto.StaffDto;
import com.spring.mapper.StaffMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
//@AllArgsConstructor
public class StaffServiceImpl implements StaffService {
//	public class StaffServiceImpl implements StaffService

	@Setter(onMethod_ = @Autowired)
	private StaffMapper mapper;

	@Override
	public ArrayList<StaffDto> getList() {
		log.info("비지니스 계층===========");
		return mapper.getList();
	}

	@Override
	public StaffDto read(long bno) {
		return mapper.read(bno);
	}

}
