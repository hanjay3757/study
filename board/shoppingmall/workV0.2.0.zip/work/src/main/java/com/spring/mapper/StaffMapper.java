package com.spring.mapper;

import java.util.ArrayList;

import com.spring.dto.StaffDto;

public interface StaffMapper {
	public ArrayList<StaffDto> getList();

	public StaffDto read(long bno);
}
