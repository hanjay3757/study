package com.spring.dto;

import lombok.Data;

@Data
public class StaffDto {

	public StaffDto() {
	};

	private Long bno;
	private String btext;

	public StaffDto(Long bno, String btext) {
		super();
		this.bno = bno;
		this.btext = btext;
	}
}
