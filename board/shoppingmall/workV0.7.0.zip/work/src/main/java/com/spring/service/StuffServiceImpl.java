package com.spring.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.dto.StuffDto;
import com.spring.dto.CartDto;
import com.spring.mapper.StuffMapper;

import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class StuffServiceImpl implements StuffService {
    
    @Autowired
    private StuffMapper mapper;
    
    @Override
    public List<StuffDto> getItemList() {
        log.info("물건 목록 조회...");
        return mapper.getItemList();
    }
    
    @Override
    public void registerItem(StuffDto stuff) {
        log.info("물건 등록..." + stuff);
        mapper.registerItem(stuff);
    }
    
    @Override
    @Transactional
    public void addToCart(Long itemId, Long userId, int quantity) {
        log.info("장바구니에 추가: itemId=" + itemId + ", userId=" + userId + ", quantity=" + quantity);
        
        // 재고 확인
        int currentStock = mapper.checkStock(itemId);
        if (currentStock < quantity) {
            throw new RuntimeException("재고가 부족합니다.");
        }
        
        // 장바구니에 추가
        mapper.addToCart(itemId, userId, quantity);
        
        // 재고 감소
        mapper.updateStock(itemId, quantity);
    }
    
    @Override
    public List<CartDto> getCartItems(Long userId) {
        log.info("장바구니 조회: userId=" + userId);
        return mapper.getCartItems(userId);
    }
    
    @Override
    public void removeFromCart(Long cartId) {
        log.info("장바구니에서 제거: cartId=" + cartId);
        mapper.removeFromCart(cartId);
    }
    
    @Override
    public void processCheckout(Long userId) {
        // 장바구니 아이템을 주문으로 변환하는 로직 구현
        mapper.createOrder(userId);
        mapper.clearCart(userId);
    }
} 