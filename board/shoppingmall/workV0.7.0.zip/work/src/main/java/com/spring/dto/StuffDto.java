package com.spring.dto;

import lombok.Data;

@Data
public class StuffDto {
    private Long itemId;
    private String itemName;
    private int price;
    private int stock;
    private String description;
} 