import React from 'react';

function Cart() {
  return (
    <div>
      <h2>장바구니</h2>
      {/* 장바구니 구현 예정 */}
    </div>
  );
}

export default Cart;