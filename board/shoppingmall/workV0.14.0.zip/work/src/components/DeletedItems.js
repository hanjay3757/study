import React from 'react';

function DeletedItems() {
  return (
    <div>
      <h2>삭제된 물건 목록</h2>
      {/* 삭제된 물건 목록 구현 예정 */}
    </div>
  );
}

export default DeletedItems;