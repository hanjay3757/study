// src/components/RegisterItem.js
import React from 'react';

function RegisterItem() {
  return (
    <div>
      <h2>물건 등록</h2>
      {/* 등록 폼 내용 */}
    </div>
  );
}

export default RegisterItem;