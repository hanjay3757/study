import React from 'react';

function RemovedStaff() {
  return (
    <div>
      <h2>삭제된 직원 목록</h2>
      {/* 삭제된 직원 목록 구현 예정 */}
    </div>
  );
}

export default RemovedStaff;