import React from 'react';

function ItemRegister() {
  return (
    <div>
      <h2>물건 등록</h2>
      {/* 물건 등록 폼 구현 예정 */}
    </div>
  );
}

export default ItemRegister;