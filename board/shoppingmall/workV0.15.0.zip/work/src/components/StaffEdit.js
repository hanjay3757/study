import React from 'react';

function StaffEdit() {
  return (
    <div>
      <h2>직원 정보 수정</h2>
      {/* 직원 수정 폼 구현 예정 */}
    </div>
  );
}

export default StaffEdit;