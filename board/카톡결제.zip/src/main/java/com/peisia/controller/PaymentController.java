package com.peisia.controller;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;

@CrossOrigin(origins = "http://localhost:3000") // 3000포트에서의 요청 허용
@RequestMapping("/pay/*")
@Controller
public class PaymentController {
	@RequestMapping("/buy")
	public void buy() {
	}

	// 카카오페이 결제 준비 API 호출
	@RequestMapping("/buyGold")
	public ResponseEntity<Map<String, Object>> buyGold() {
		try {
			// 카카오페이 결제 API URL 설정
			URL url = new URL("https://kapi.kakao.com/v1/payment/ready");
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Authorization", "KakaoAK 1c159018a76b3e561e48e6c04e2badfe");
			connection.setRequestProperty("Content-type", "application/x-www-form-urlencoded;charset=utf-8");
			connection.setDoOutput(true);

			// 요청 파라미터 구성
			String parameters = "cid=TC0ONETIME&" + // 테스트용 CID
					"partner_order_id=gold_001&" + // 주문 번호
					"partner_user_id=user_1234&" + // 사용자 ID
					"item_name=Gold Pack&" + // 상품 이름
					"quantity=1&" + "total_amount=10000&" + // 금액
					"vat_amount=909&" + "tax_free_amount=0&" + "approval_url=http://localhost:3000/success&" + // 성공
																												// 리다이렉트
																												// URL
					"fail_url=http://localhost:3000/fail&" + // 실패 리다이렉트 URL
					"cancel_url=http://localhost:3000/cancel"; // 취소 리다이렉트 URL

			// 요청 전송
			try (DataOutputStream out = new DataOutputStream(connection.getOutputStream())) {
				out.writeBytes(parameters);
				out.flush();
			}

			// 응답 처리
			int responseCode = connection.getResponseCode();
			InputStream responseStream = (responseCode == 200) ? connection.getInputStream()
					: connection.getErrorStream();
			BufferedReader in = new BufferedReader(new InputStreamReader(responseStream));
			StringBuilder response = new StringBuilder();
			String line;
			while ((line = in.readLine()) != null) {
				response.append(line);
			}
			in.close();

			// 응답을 JSON으로 파싱
			JSONObject jsonResponse = new JSONObject(response.toString());
			String nextRedirectUrl = jsonResponse.getString("next_redirect_pc_url");

			// 서버에서 응답으로 리디렉션 URL 반환
			Map<String, Object> result = new HashMap<>();
			result.put("next_redirect_pc_url", nextRedirectUrl);

			return ResponseEntity.ok(result);

		} catch (IOException e) {
			e.printStackTrace();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("error", "카카오페이 결제 준비 오류"));
		}
	}
}
