package com.peisia.jsp.board;

public class Board {
	static public final int LIST_AMOUNT = 5;	//하나의 리스트에 보일 글 수
	static public final int PAGE_LINK_AMOUNT = 3;	//페이지 링크 한 블럭에 보일 페이지 링크 갯수
	
	/* table들 */
	////	게시판
	public static final String TABLE_PS_BOARD_FREE = "PS_BOARD_FREE";	//자유게시판
	
	
	int totalPage = 0;	//전체 페이지 수.	🐇페이징🐇
	//페이징 블럭(페이징 처리랑 다 같이)
	
	//전체 페이지 수 구해서 저장해두기
	
	
	//검색
	
	
}
