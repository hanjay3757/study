import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate, useLocation } from 'react-router-dom';

function ItemList({ isLoggedIn, isAdmin }) {
  const navigate = useNavigate();
  const location = useLocation();
  const [items, setItems] = useState([]);
  const [quantities, setQuantities] = useState({});
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    loadItems();
  }, [refreshKey]);

  useEffect(() => {
    if (location.state?.refresh) {
      loadItems();
    }
  }, [location]);

  const loadItems = async () => {
    try {
      const response = await axios.get(`http://localhost:8080/mvc/stuff/item/list?_t=${Date.now()}`, {
        withCredentials: true
      });
      
      const itemsToProcess = response.data;
      for (const item of itemsToProcess) {
        if (item.item_stock === 0 && !item.item_delete) {
          try {
            const params = new URLSearchParams();
            params.append('item_id', item.item_id);
            
            await axios.post(
              'http://localhost:8080/mvc/stuff/item/delete',
              params,
              {
                withCredentials: true,
                headers: {
                  'Content-Type': 'application/x-www-form-urlencoded'
                }
              }
            );
          } catch (error) {
            // 에러 처리는 유지
          }
        }
      }
      
      const activeItems = itemsToProcess.filter(item => 
        !item.item_delete && item.item_stock > 0
      );
      
      setItems(activeItems);
      
      const initialQuantities = {};
      activeItems.forEach(item => {
        initialQuantities[item.item_id] = 1;
      });
      setQuantities(initialQuantities);
    } catch (error) {
      // 에러 처리는 유지
    }
  };

  const refreshList = () => {
    setRefreshKey(prevKey => prevKey + 1);
  };

  const handleDelete = async (item_id) => {
    try {
      if (!isAdmin) {
        alert('관리자 권한이 필요합니다.');
        return;
      }
      if(!item_id){
        alert("삭제할 물건이 없습니다.")
        return;
      }

      if (window.confirm('이 물건을 삭제하시겠습니까?')) {
        const params = new URLSearchParams();
        params.append('item_id', item_id);
        
        const response = await axios.post(
          'http://localhost:8080/mvc/stuff/item/delete', 
          params,
          { 
            withCredentials: true,
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded'
            }
          }
        );

        if (response.data === 'redirect:/stuff/item/list' || 
            response.status === 200 || 
            response.data.success) {
          alert('물건이 삭제되었습니다.');
          loadItems();
        } else {
          alert(response.data.message || '삭제에 실패했습니다.');
        }
      }
    } catch (error) {
      alert('물건 삭제 중 오류가 발생했습니다.');
    }
  };

  const handleQuantityChange = (itemId, value) => {
    const item = items.find(item => item.item_id === itemId);
    if (!item) return;

    const newQuantity = Math.max(1, Math.min(value, item.item_stock));
    setQuantities(prev => ({
      ...prev,
      [itemId]: newQuantity
    }));
  };

  const handleAddToCart = async (itemId, quantity) => {
    try {
      if (!isLoggedIn) {
        alert('로그인이 필요합니다.');
        return;
      }

      const params = new URLSearchParams();
      params.append('itemId', itemId);
      params.append('quantity', quantity);

      const response = await axios.post(
        'http://localhost:8080/mvc/stuff/api/cart/add',
        params,
        {
          withCredentials: true,
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          }
        }
      );

      if (response.data.status === 'success') {
        alert(response.data.message);
        loadItems();
      } else {
        throw new Error(response.data.message);
      }
    } catch (error) {
      console.error('장바구니 추가 중 오류:', error);
      alert(error.response?.data?.message || '장바구니 추가에 실패했습니다.');
    }
  };

  return (
    <div className="item-list">
      {isAdmin && (
        <button onClick={refreshList} className="refresh-button">
          목록 새로고침
        </button>
      )}
      <h2>물건 목록</h2>
      <div className="items-container">
        {items.map(item => (
          <div key={item.item_id} className="item-card">
            <div className="item-image">
              <img 
                src={item.image_url || 'https://via.placeholder.com/400x200'} 
                alt={item.item_name}
                onError={(e) => {
                  e.target.src = 'https://via.placeholder.com/400x200'; 
                }}
              />
            </div>
            <div className="item-content">
              <h3>{item.item_name}</h3>
              <p>가격: {item.item_price.toLocaleString()}원</p>
              <p>재고: {item.item_stock.toLocaleString()}개</p>
              <p>{item.item_description}</p>
              
              {isAdmin && (
                <div className="admin-controls">
                  <button 
                    onClick={() => navigate(`/stuff/item/edit?itemId=${item.item_id}`)}
                    className="edit-button"
                  >
                    수정
                  </button>
                  <button 
                    onClick={() => handleDelete(item.item_id)}
                    className="delete-button"
                  >
                    삭제
                  </button>
                </div>
              )}

              {isLoggedIn && item.item_stock > 0 && (
                <div className="cart-controls">
                  <input
                    type="number"
                    min="1"
                    max={item.item_stock}
                    value={quantities[item.item_id] || 1}
                    onChange={(e) => handleQuantityChange(item.item_id, parseInt(e.target.value))}
                    className="quantity-input"
                  />
                  <button 
                    onClick={() => handleAddToCart(item.item_id, quantities[item.item_id] || 1)}
                    className="add-to-cart-button"
                  >
                    장바구니에 추가
                  </button>
                </div>
                 
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default ItemList;