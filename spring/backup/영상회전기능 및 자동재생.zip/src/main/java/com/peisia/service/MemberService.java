package com.peisia.service;

import com.peisia.dto.MemberVO;

public interface MemberService {
    public void register(MemberVO member);
}
