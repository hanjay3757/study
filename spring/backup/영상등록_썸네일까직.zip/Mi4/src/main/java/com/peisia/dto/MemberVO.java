package com.peisia.dto;

import lombok.Data;

@Data
public class MemberVO {
    private String userid;
    private String userpw;
    private String username;
    private String email;
}
