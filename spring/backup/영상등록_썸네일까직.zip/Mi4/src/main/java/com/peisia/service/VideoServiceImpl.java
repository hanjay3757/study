package com.peisia.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.peisia.dto.VideoVO;
import com.peisia.mapper.VideoMapper;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
@AllArgsConstructor
public class VideoServiceImpl implements VideoService {

	private final VideoMapper videoMapper; // MyBatis를 사용한다고 가정

	@Override
	public List<VideoVO> getList() {
		log.info("getList.........");
		return videoMapper.getAllVideos();
	}

	@Override
	public VideoVO read(Long vno) {
		// DB에서 특정 비디오를 조회하는 메서드
		return videoMapper.getVideoById(vno);
	}

	@Override
	public void remove(Long vno) {
		// DB에서 비디오를 삭제하는 메서드
		videoMapper.deleteVideo(vno);
	}

	@Override
	public void register(VideoVO video) {
		// DB에 새로운 비디오를 등록하는 메서드
		videoMapper.insertVideo(video);
	}
}
