package com.peisia.mapper;

import java.util.List;

import com.peisia.dto.VideoVO;

public interface VideoMapper {

	// 모든 비디오 목록을 가져오는 메서드
	public List<VideoVO> getAllVideos();

	// 특정 비디오를 ID로 조회하는 메서드
	public VideoVO getVideoById(Long vno);

	// 비디오 삭제 메서드
	public void deleteVideo(Long vno);

	// 비디오 등록 메서드
	public void insertVideo(VideoVO video);
}
