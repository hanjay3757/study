package com.peisia.dto;

import java.util.Date;

import lombok.Data;

@Data
public class VideoVO {
	private Long vno; // 비디오 번호
	private String title; // 비디오 제목
	private String writer; // 비디오 작성자
	private String url; // URL 필드 추가
	private Date regdate; // 등록일
}
