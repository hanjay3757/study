package com.peisia.mapper;

import com.peisia.dto.MemberVO;

public interface MemberMapper {
    public void register(MemberVO member);
}
