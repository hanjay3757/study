package com.peisia.dto;

import lombok.Data;

@Data
public class PjDto {
	private int no;
	private String name;
	private int level;
	private int gold;
	private String content;
}