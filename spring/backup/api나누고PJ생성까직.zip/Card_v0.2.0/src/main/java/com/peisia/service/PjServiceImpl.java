package com.peisia.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.peisia.dto.PjDto;
import com.peisia.dto.CardDto;
import com.peisia.dto.SelectCardDto;
import com.peisia.mapper.PjMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class PjServiceImpl implements PjService {

	@Setter(onMethod_ = @Autowired)
	private PjMapper mapper;

	@Override
	public List<PjDto> getPjList() {
		return mapper.getPjList();
	}

	public List<CardDto> getPjMembers(int projectNo) {
		return mapper.selectPjMembers(projectNo);
	}

	@Override
	public void pjMemberAdd(SelectCardDto selectCardDto) {
		mapper.insertPjMember(selectCardDto);
	}

	@Override
	public void createPj() {
		mapper.createPj();
	}
}