package com.peisia.service;

import com.peisia.dto.PjDto;
import com.peisia.dto.SelectCardDto;
import java.util.List;

public interface PjService {
	public List<PjDto> getPjList();
	public void createPj();
	void pjMemberAdd(SelectCardDto selectCardDto);
}
