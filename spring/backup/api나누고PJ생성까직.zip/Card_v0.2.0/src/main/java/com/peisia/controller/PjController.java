package com.peisia.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.peisia.dto.CardDto;
import com.peisia.dto.PjDto;
import com.peisia.dto.SelectCardDto;
import com.peisia.service.CardService;
import com.peisia.service.PjService;

import lombok.Setter;

@CrossOrigin(origins = "http://localhost:3000", allowCredentials = "true")
@RequestMapping("/card/pj")
@RestController
public class PjController {

	@Setter(onMethod_ = @Autowired)
	private PjService service;

	@Setter(onMethod_ = @Autowired)
	private CardService cardService;

	@GetMapping("/getPjList")
	public List<PjDto> getPjList() {
		return service.getPjList();
	}

	@RequestMapping("/pjMemberAdd")
	public void pjMemberAdd(@RequestBody SelectCardDto c) {
		cardService.pjMemberAdd(c);
	}

	@RequestMapping("/getPjMember")
	public ArrayList<CardDto> getParty(@RequestParam("no") int no) {
		ArrayList<CardDto> n = cardService.getPjMember(no);
		System.out.println("==== pj 멤버 카드 수:" + n.size());
		return n;
	}

	@RequestMapping("/clearPjMember/{projectId}")
	public void clearPjMember(@PathVariable("projectId") int projectId) {
		cardService.clearPjMember();
	}

	@GetMapping("/create")
	public ResponseEntity<String> createPj() {
		try {
			service.createPj();
			// return ResponseEntity.ok("프로젝트가 생성되었습니다.");
			return ResponseEntity.ok("success");
		} catch (Exception e) {
			return ResponseEntity.badRequest().body("fail");
		}
	}
}
