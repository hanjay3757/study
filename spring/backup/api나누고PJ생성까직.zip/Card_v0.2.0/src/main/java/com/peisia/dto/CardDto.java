package com.peisia.dto;

import lombok.Data;

@Data
public class CardDto {
	private Long no;
	private String job;
	private String grade;
	private String id;
	private Long deployment;

	public CardDto() {

	}

	public CardDto(String job, String grade) {
		this.job = job;
		this.grade = grade;
	}

	public void setDeployment(Long deployment) {
		this.deployment = deployment;
	}

}