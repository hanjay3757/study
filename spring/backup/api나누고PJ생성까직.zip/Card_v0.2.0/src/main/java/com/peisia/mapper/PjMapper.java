package com.peisia.mapper;

import java.util.List;

import com.peisia.dto.CardDto;
import com.peisia.dto.PjDto;
import com.peisia.dto.SelectCardDto;

public interface PjMapper {
	public List<PjDto> getPjList();

	public List<CardDto> selectPjMembers(int projectNo);

	public void insertPjMember(SelectCardDto selectCardDto);

	public void createPj();
}
