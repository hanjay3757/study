package com.peisia.dto;

import lombok.Data;

@Data
public class SelectCardDto {
	private Long no;
//	private String job;
//	private String grade;
	private String id;
	private Long deployment;
}