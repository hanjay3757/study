package com.peisia.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.peisia.dto.WealthDto;
import com.peisia.mapper.ShopMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
//@AllArgsConstructor
public class ShopServiceImpl implements ShopService {

	@Setter(onMethod_ = @Autowired)
	private ShopMapper mapper;

	@Transactional  // 트랜잭션 처리
	@Override
	public void buyDice() {
		// 골드 차감
		mapper.payGold();  // 10000 골드 차감
		// 주사위 증가
		mapper.buyDice();  // 주사위 1개 증가
	}

	@Override
	public void buyGold() {
		mapper.buyGold();
	}

	@Override
	public WealthDto getWealth() {
		return mapper.getWealth();
	}

	@Override
	public void payGold() {
		mapper.payGold();
	}
}