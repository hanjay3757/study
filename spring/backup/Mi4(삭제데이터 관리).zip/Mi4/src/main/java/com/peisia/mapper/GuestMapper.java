package com.peisia.mapper;

import java.util.ArrayList;

import com.peisia.dto.GuestDto;

public interface GuestMapper {
	public ArrayList<GuestDto> getList(int limitIndex);

	public GuestDto read(long bno);

	public void del(long bno);

	public void write(GuestDto dto);

	public void modify(GuestDto dto);
//행위 service에서  호출 하고 있는거  

	// DB 데이터를 갖고오고싶다 이러면 매퍼도 쓰는거 아니면 서비스 하나로 해결
}
