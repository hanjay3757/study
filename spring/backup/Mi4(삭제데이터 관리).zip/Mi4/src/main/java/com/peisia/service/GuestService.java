package com.peisia.service;

import java.util.ArrayList;

import com.peisia.dto.GuestDto;

public interface GuestService {
	public ArrayList<GuestDto> getList(int currentPage);

	public GuestDto read(long bno);

	public void del(long bno);

//중계 역활역 만함
	public void write(GuestDto dto);

	public void modify(GuestDto dto);
	// 컨트롤러에서 해달래 같이 정보 넘기기 호출역활 밖에 안하고있음
}
