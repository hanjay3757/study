function deleteVideo(event, vno) {
    event.preventDefault();
    if (confirm('이 비디오를 삭제하시겠습니까?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = contextPath + '/video/remove';
        
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'vno';
        input.value = vno;
        
        form.appendChild(input);
        document.body.appendChild(form);
        form.submit();
    }
}

document.addEventListener('DOMContentLoaded', function() {
    const cards = document.querySelectorAll('.video-card');
    
    cards.forEach(card => {
        const handleMouseMove = (e) => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            
            const rotateX = -(y - centerY) / 10;
            const rotateY = (x - centerX) / 10;
            
            // 카드 전체 회전
            card.style.transform = `
                perspective(1000px) 
                rotateX(${rotateX}deg) 
                rotateY(${rotateY}deg)
            `;

            // 썸네일 회전 (반대 방향)
            const thumbnail = card.querySelector('.thumbnail');
            if (thumbnail) {
                thumbnail.style.transform = `
                    perspective(1000px)
                    rotateX(${-rotateX * 0.5}deg)
                    rotateY(${-rotateY * 0.5}deg)
                    scale3d(1.05, 1.05, 1.05)
                `;
            }

            card.style.transition = 'none';
            if (thumbnail) thumbnail.style.transition = 'none';
        };

        const handleMouseLeave = () => {
            card.style.transition = 'all 0.3s ease';
            card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0)';
            
            const thumbnail = card.querySelector('.thumbnail');
            if (thumbnail) {
                thumbnail.style.transition = 'all 0.3s ease';
                thumbnail.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) scale3d(1, 1, 1)';
            }
        };

        card.addEventListener('mousemove', handleMouseMove);
        card.addEventListener('mouseleave', handleMouseLeave);
    });
});
