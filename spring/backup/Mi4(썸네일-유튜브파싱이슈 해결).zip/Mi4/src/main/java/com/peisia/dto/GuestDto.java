package com.peisia.dto;

import lombok.Data;

@Data
public class GuestDto {
	private Long bno;
	private String btext;
//사용자가 요청했을때  게시판 번호나 내용같은걸 기본으로 제공하는거
}