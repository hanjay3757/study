package com.peisia.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.peisia.dto.VideoVO;
import com.peisia.service.VideoService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/video")
@Log4j
@AllArgsConstructor
public class VideoController {

	private VideoService service;

	@GetMapping("/list")
	public void list(Model model) {
		log.info("비디오 목록 표시");
		model.addAttribute("list", service.getList());
	}

	@GetMapping("/read")
	public String read(@RequestParam("vno") Long vno, Model model) {
		log.info("비디오 읽기: " + vno);
		model.addAttribute("video", service.read(vno));
		return "video/read";
	}

	@GetMapping("/register")
	public void register() {
	}

	@PostMapping("/register")
	public String register(VideoVO video) {
		log.info("비디오 등록: " + video);
		service.register(video);
		return "redirect:/video/list";
	}

	@PostMapping("/remove")
	public String remove(@RequestParam("vno") Long vno) {
		log.info("비디오 삭제: " + vno);
		service.remove(vno);
		return "redirect:/video/list";
	}
}
