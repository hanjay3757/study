package com.peisia.service;

import org.springframework.stereotype.Service;
import com.peisia.dto.MemberVO;
import com.peisia.mapper.MemberMapper;
import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
@AllArgsConstructor
public class MemberServiceImpl implements MemberService {
    
    private MemberMapper mapper;
    
    @Override
    public void register(MemberVO member) {
        log.info("회원가입: " + member);
        mapper.register(member);
    }
}
