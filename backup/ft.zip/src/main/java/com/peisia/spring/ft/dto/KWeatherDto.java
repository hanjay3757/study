
package com.peisia.spring.ft.dto;

public class KWeatherDto {

	public Response response;

}
