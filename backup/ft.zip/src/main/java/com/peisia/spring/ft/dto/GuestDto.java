package com.peisia.spring.ft.dto;

import lombok.Data;

//lombok에서 꺼내옴
@Data
public class GuestDto {
	private Long bno;
	private String btext;
}