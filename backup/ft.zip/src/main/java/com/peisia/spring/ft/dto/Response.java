
package com.peisia.spring.ft.dto;

public class Response {

	public Header header;
	public Body body;

}
