
package com.peisia.spring.ft.dto;

public class Header {

	public String resultCode;
	public String resultMsg;

}
