import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.peisia.c.util.Cw;

@WebServlet("/board/*") // /board/로 시작하는 모든 URL 패턴에 대해 이 서블릿을 매핑
public class Control extends HttpServlet {
	String nextPage; // 이동할 페이지 경로를 저장할 변수
	Dao dao; // 데이터베이스 작업을 처리할 Dao 객체

	// 서블릿 초기화 메소드. 서블릿이 처음 로딩될 때 호출됨.
	@Override
	public void init() throws ServletException {
		dao = new Dao(); // Dao 객체 초기화 (DB 작업을 위한 객체)
	}

	// HTTP GET 요청을 처리하는 메소드
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// 요청 경로에서 '/board/*' 이후의 경로를 가져옴. 예: '/del', '/write' 등
		String action = request.getPathInfo();

		Cw.wn("action:" + action); // 요청 경로(action)를 로그로 출력 (디버깅용)

		if (action != null) { // action 값이 null이 아니면 아래 switch 문을 실행
			switch (action) {
			case "/del": // '/board/del'로 요청이 오면 삭제 작업
				Cw.wn("삭제"); // 로그로 '삭제' 작업 출력
				String no = request.getParameter("no"); // 삭제할 항목의 ID (no) 파라미터 받기
				request.setAttribute("no", no); // 삭제할 항목의 ID를 JSP로 전달
				nextPage = "/confirmDelete.jsp"; // 삭제 확인 페이지로 이동
				break;

			case "/write": // '/board/write'로 요청이 오면 글쓰기 페이지로 이동
				Cw.wn("쓰기"); // 로그로 '쓰기' 작업 출력
				nextPage = "/write.jsp"; // 글쓰기 페이지로 이동
				break;

			case "/edit": // '/board/edit'로 요청이 오면 글 수정 페이지로 이동
				Cw.wn("수정"); // 로그로 '수정' 작업 출력
				nextPage = "/edit.jsp"; // 글 수정 페이지로 이동
				break;

			case "/read": // '/board/read'로 요청이 오면 글 읽기 페이지로 이동
				Cw.wn("읽기"); // 로그로 '읽기' 작업 출력
				nextPage = "/read.jsp"; // 글 읽기 페이지로 이동
				break;

			case "/list": // '/board/list'로 요청이 오면 글 목록 페이지로 이동
				Cw.wn("리스트"); // 로그로 '리스트' 작업 출력
				nextPage = "/list.jsp"; // 글 목록 페이지로 이동
				break;
			}

			// 지정된 페이지(nextPage)로 이동하기 위해 RequestDispatcher를 사용
			RequestDispatcher d = request.getRequestDispatcher(nextPage);
			d.forward(request, response); // 해당 페이지로 포워드
		}
	}
}
