/**
 * 
 */
/**
 * @author hoyangi
 *
 */
module KioskCatCafe {
}