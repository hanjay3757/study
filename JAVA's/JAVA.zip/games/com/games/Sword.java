package com.games;

public class Sword extends Item {
	int attack;

}
