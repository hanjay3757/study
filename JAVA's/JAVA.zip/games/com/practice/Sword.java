package com.practice;

public class Sword extends Item {
	int attack;

}
