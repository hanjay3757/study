package com.peisia.c.sang4;

public class Father {
	void kimchi() {
		System.out.println("종가집 전통 김치");
	}
}
