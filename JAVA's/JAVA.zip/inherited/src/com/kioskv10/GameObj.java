package com.kioskv10;

public class GameObj {
	public static void main(String[] args) {

		int hp;
		int attack;
		System.out.println();
	}
}