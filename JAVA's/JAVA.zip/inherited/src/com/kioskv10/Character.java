package com.kioskv10;

public class Character extends GameObj {
	int hp;
	int attack;

}
