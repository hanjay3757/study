module Kiosk_v10 {
}