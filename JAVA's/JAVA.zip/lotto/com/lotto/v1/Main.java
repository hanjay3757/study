package com.lotto.v1;

public class Main {
	public static void main(String[] args) {
		Lotto lotto = new Lotto();
		lotto.run();
	}
}
