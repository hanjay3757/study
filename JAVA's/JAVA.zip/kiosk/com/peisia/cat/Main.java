package com.peisia.cat;

public class Main {

	public static void main(String[] args) {
		Kiosk k = new Kiosk();
		k.run();
	}
}
