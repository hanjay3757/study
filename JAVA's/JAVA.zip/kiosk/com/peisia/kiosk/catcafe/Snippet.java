package com.peisia.kiosk.catcafe;

public class Snippet {
	public static void title() {
			line();
			Cw.wn("************** 고양이 카페   ***************");
			line();
}

