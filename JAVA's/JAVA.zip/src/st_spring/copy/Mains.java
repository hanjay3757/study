package st_spring.copy;

//		main
public class Mains {
	public static void main(String[] args) {
//		console.log();
		int a = 1;
		for (int i = 0; i < 3; i++) {
			if (i == 1) {
				break;
			}
		}
//		sysout
		System.out.println("개");
	}

	int x = 2;
}
