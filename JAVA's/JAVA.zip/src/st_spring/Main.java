package st_spring;

public class Main {

//	주석입니다.
	/*
	 * ㅁㅁㅁ ㅁㅁ ㅁㅁ 컨트롤 쉬프트 / 컨트롤 쉬프트 f 정리
	 */
	public static void main(String[] args) {
		System.out.println("헬로월드!!");
	}
}