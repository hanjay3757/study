package com.cat;

public class Cat {
	String name;
	int age;
	long id;

//20억이 넘는 수
	void info() {
		String s = this.name + this.age + this.id;
		System.out.println();
	}
}
