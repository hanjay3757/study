package com.cat;

public class Main {
	public static void main(String[] args) {
//		Cat kitty = new Cat();
//		kitty.name = "kitty";
//		kitty.age = 10;
//		kitty.id = 5;
//		kitty.info();
		int a = 1;
		float x = 1.5f;
		float y = a + x;
		System.out.println(y);
		// float y = (float)a + x; 자료형
//		float y = ((float) a + x);
//		
	}

}
