package com.cats;

public class Main {

	public static void main(String[] args) {
//		Cat kitty = new Cat();
//		kitty.name = "키티";
		Cat kitty = new Cat(5, "키티", "식빵굽기");
		kitty.info();
	}
}
