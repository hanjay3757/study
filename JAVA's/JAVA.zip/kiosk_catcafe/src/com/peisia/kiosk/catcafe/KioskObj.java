package com.peisia.kiosk.catcafe;

import java.util.ArrayList;

public class KioskObj {
	public static ArrayList<Order> basket = new ArrayList<>();
}
