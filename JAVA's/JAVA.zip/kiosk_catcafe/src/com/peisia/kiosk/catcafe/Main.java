package com.peisia.kiosk.catcafe;

public class Main {

	public static void main(String[] args) {
		Kiosk k = new Kiosk();
		k.run();
	}
	// 진짜 끌꺼냐고 질문이 있어야 exe 장바구니 결과 나옴 scanner 해서 유저입력을 잠깐 잡아놔야함
}
