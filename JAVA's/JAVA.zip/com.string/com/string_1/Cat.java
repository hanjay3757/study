package com.string_1;

public class Cat {
	public static void main(String[] args) {
//		int n[] = new int[2];
		int x[] = { 1, 2 };
//		int []x = { 1, 2 };
		// 같은거
		System.out.println(x[1]);
	}
}
