package com.string_3;

public class Cat {
	public static void main(String[] args) {
		String r = 1 > 2 ? "야옹" : "멍";

		System.out.println(r);
	}
}
