package com.string_4;

public class Cat {
	public static void main(String[] args) {
		int n[] = new int[2];
//배열 
		int x[] = { 1, 2 };
		String s[] = { "개", "고양이" };

		System.out.println(s[1]);
	}
}
