package com.rpc03;

public class Rpc {
	public static void main(String[] args) {
		System.out.println();
	}
}
