package com.peisia.service;

import java.util.List;

import com.peisia.dto.VideoVO;

public interface VideoService {
	public List<VideoVO> getList();
}