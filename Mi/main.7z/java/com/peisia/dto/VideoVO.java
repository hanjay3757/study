package com.peisia.dto;

import java.sql.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class VideoVO {
	private Long vno; // 비디오 번호
	private String title; // 제목
	private String content; // 내용
	private String writer; // 작성자
	private Date regdate; // 등록일
	private Date updateDate; // 수정일
}