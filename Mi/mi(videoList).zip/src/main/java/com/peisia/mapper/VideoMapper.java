package com.peisia.mapper;

import java.util.List;

import com.peisia.dto.VideoVO;

public interface VideoMapper {
	public List<VideoVO> getList();
}
