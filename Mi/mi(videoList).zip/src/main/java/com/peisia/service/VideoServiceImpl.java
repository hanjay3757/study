package com.peisia.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.peisia.dto.VideoVO;
import com.peisia.mapper.VideoMapper;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Service
@Log4j
@AllArgsConstructor
public class VideoServiceImpl implements VideoService {

	private VideoMapper mapper;

	@Override
	public List<VideoVO> getList() {
		log.info("getList......");
		return mapper.getList();
	}
}